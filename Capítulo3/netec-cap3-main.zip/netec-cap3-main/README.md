
# Capitulo 3: Listado productos

## Estandaras

* Nombre de tablas creadas ya sea desde base o migracianes en plurar
* Uso de los factories para las pruebas en desarrollo
* Hacer uso de la variable fillable en los modelos para que al insertar datos solo se reciban los datos establecidos
* Listado de productos paginados desde el controlador
* Hacer uso de un solo idioma el codigo, aparte de datos quemados en html o registro de base de datos
* Vistas blade en su correspondiente carpeta para cuando se agreguen nuevos modulos 
